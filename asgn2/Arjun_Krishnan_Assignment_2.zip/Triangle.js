function drawTriangle3D(offset) {
  gl.drawArrays(gl.TRIANGLES, offset, 12);
}